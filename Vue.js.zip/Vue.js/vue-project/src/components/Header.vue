<script setup>
import NavbarVue from './Navbar.vue';
</script>

<template>
    <div>
        <main>
        <div class="container">
            <div class="row">
                <div id="icon" class="col justify-content-start">
                    <h2>Company</h2>
                </div>
                <div class="col d-flex justify-content-end">
                    <a href="#">Contact us</a>
                    <a href="#">Get started</a>
                    <a href="#">About us</a>
                    <a href="#">Portfolio</a>
                    <a id="se" type="search" href="#">Sign up</a>
                </div>

            </div>
            <div id="div2">
            <h1>Social media<br>dashboard</h1>
            <p id="error">Lorem ipsum dolor sit amet consectetur<br>adipisicing elit. Est cum voluptates<br>delectus sequi, sit ipsa
                molestias temporibus!<br>Iure autem quisquam earum ab incidunt<br>a obcaecati alias dolore asperiores placeat
                vero...</p>
                <button type="button" class="btn">Get started!</button>
            </div>
        </div>
    </main>
    <NavbarVue/>
    </div>
</template>
<style scoped>

</style>