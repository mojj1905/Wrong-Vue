<script setup>
import HeaderVue from './components/Header.vue';
import NavbarVue from './components/Navbar.vue';
</script>

<template>
  <div>
    <HeaderVue/>
    <NavbarVue/>
  </div>
</template>

<script>
export default {
    data(){
        return{
          
           
        }
    } 

}
</script>

<style scoped>
</style>





